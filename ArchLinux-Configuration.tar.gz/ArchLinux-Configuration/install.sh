#!/bin/bash

set -e
set -x

function install_pacman() {
        sudo pacman -Syyu --noconfirm \
                wine \
                firefox \
                wget \
                vim \
                vi \
                pwgen \
                htop \
                chromium \
                discord \
                polkit-gnome \
                libreoffice-fresh \
                nm-connection-editor \
                networkmanager \
                networkmanager-openvpn \
                ntfs-3g \
                vlc \
                gnome-system-monitor \
                udisks2 \
                remmina \
                freerdp \
                zip \
                unzip \
                postfix \
                npm \
                ruby \
                wine-mono \
                lib32-vkd3d \
                wine-gecko \
                winetricks \
                git \
                rofi \
                polybar \
                rsync \
                ttf-font-awesome \
                awesome-terminal-fonts \
                powerline \
                powerline-fonts \
                wqy-bitmapfont \
                wqy-microhei \
                wqy-microhei-lite \
                wqy-zenhei \
                ttf-font-awesome \
                ttf-roboto \
                ttf-roboto-mono \
                noto-fonts-cjk \
                adobe-source-han-serif-cn-fonts \
                picom \
                feh \
                lxappearance \
                thunar \
                thunar-volman \
                xfce4-settings \
                neofetch \
                bitwarden \
                base-devel \
                dkms \
                arc-gtk-theme \
                gnome-screenshot \
                gnome-disk-utility \
                nautilus \
                docker \
                transmission-gtk \
                dosfstools \
                perl-text-iconv \
                extra/xdebug \
                extra/gnome-calculator \
                composer \
                thunderbird \
                spotify-launcher
}

function install_aur() {
        if [ ! -f /usr/bin/yay ]; then
                rm -Rf ./yay-bin/
                git clone https://aur.archlinux.org/yay-bin.git
                cd ./yay-bin/
                makepkg -si --noconfirm
                cd ../
                rm -Rf ./yay-bin/
        fi

        yay -Syyu --needed --noconfirm \
                aur\opera
}

function configure_keyboard_french_canada() {
        keyboard_file=/etc/X11/xorg.conf.d/00-keyboard.conf
        if ! grep "ca(fr)" $keyboard_file &>/dev/null; then
                sudo rsync -avPh ./xorg.conf.d/00-keyboard.conf $keyboard_file
        fi
}

function enable_network_manager() {
        if [ $(systemctl is-enabled NetworkManager) = "disabled" ]; then
                sudo systemctl enable --now NetworkManager
        fi
}

function configure_mariadb() {
        if [ ! -f /etc/my.cnf ]; then
                sudo pacman -Syyu --noconfirm \
                        mariadb \
                        mariadb-clients
        fi

        if [ $(systemctl is-enabled mariadb) = "disabled" ]; then
                sudo mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql
                sudo systemctl enable --now mariadb
        fi
}

function configure_postfix() {
        if [ $(systemctl is-enabled postfix) = "disabled" ]; then
                postfix_file=/etc/postfix/main.cf
                sudo chmod o+w $postfix_file
                sudo sed -i 's/#relayhost = \[an\.ip\.add\.ress\]/relayhost = 127\.0\.0\.1:1025/' $postfix_file
                sudo chmod o-w $postfix_file
                sudo systemctl enable --now postfix
        fi
}

function maildev_docker() {
        if [ $(systemctl is-enabled docker.service) = "disabled" ]; then
                sudo systemctl enable --now docker.service
        fi
        if ! sudo docker ps | grep mail; then
                sudo docker run -d --restart unless-stopped -p 1080:1080 -p 1025:1025 dominikserafin/maildev:latest
        fi
}

function update_config() {
        rsync -avPh ./config/* ~/.config/
        rsync -avPh ./Pictures ~/
}

function main() {
        install_pacman
        install_aur
        configure_keyboard_french_canada
        enable_network_manager
        configure_mariadb
        configure_postfix
        maildev_docker
        update_config

        echo -e "\nLa configuration est terminée"
}

main
